import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:herfatek/custom_widgets/custom_text.dart';
import 'package:herfatek/custom_widgets/main_button.dart';
import 'package:herfatek/model/craft_model.dart';
import 'package:herfatek/model/pages_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:herfatek/utils/assets.dart';
import 'package:herfatek/views/course_details_screen.dart';
import 'package:herfatek/views/herfy_details_screen.dart';

class PagesScreen extends StatefulWidget {
  String type;
  String name;
  PagesScreen({Key? key, required this.type, required this.name})
      : super(key: key);

  @override
  _PagesScreenState createState() => _PagesScreenState();
}

class _PagesScreenState extends State<PagesScreen> {
  PagesModel? page;

  void fetchPage() async {
    PagesModel? pp = await getPages(widget.type);
    setState(() {
      page = pp;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchPage();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.name,
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 20.h,
            ),
            CustomText(
              text: page?.txt ?? "",
              textColor: Colors.black,
              fontWeight: FontWeight.normal,
              alignment: Alignment.centerRight,
              fontSize: 20,
            )
          ],
        ),
      ),
    );
  }
}
