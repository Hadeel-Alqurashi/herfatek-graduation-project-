import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svprogresshud/flutter_svprogresshud.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:herfatek/views/add_Course_Screen.dart';
import 'package:herfatek/views/add_product_images_screen.dart';
import 'package:image_picker/image_picker.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/craft_types_model.dart';
import '../model/user_model.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class ContinueHerfyInfoScreen extends StatefulWidget {
  ContinueHerfyInfoScreen({Key? key}) : super(key: key);

  @override
  State<ContinueHerfyInfoScreen> createState() =>
      _ContinueHerfyInfoScreenState();
}

class _ContinueHerfyInfoScreenState extends State<ContinueHerfyInfoScreen> {
  String email = "";
  String password = "";
  String about = "";
  String twitter = "";
  String instagram = "";
  String userImageUrl = "";
  XFile? imageFile;

  String imageUrl = "";

  String type = "";
  String selectedCraftTypeID = "";
  List<CraftTypesModel> craftsType = [];

  UserModel? _user;

  Future getImage() async {
    // if (Platform.isAndroid) {
    //   await [Permission.camera, Permission.mediaLibrary].request();
    // }
    final ImagePicker _picker = ImagePicker();
    imageFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {});
  }

  void fetchCrafts() async {
    List<CraftTypesModel> types = await getCraftsTypes();
    setState(() {
      craftsType = types;
    });

    var user = getLocalUser();
    setState(() {
      _user = user;
      type = craftsType
          .where((element) => element.uid == _user?.craftId)
          .first
          .title;
      selectedCraftTypeID = craftsType
          .where((element) => element.uid == _user?.craftId)
          .first
          .uid;
      twitter = _user?.twitterUrl ?? "";
      instagram = _user?.instagramUrl ?? "";
      about = _user?.about ?? "";
      userImageUrl = _user?.userImageUrl ?? "";
    });
  }

  Future uploadImage() async {
    SVProgressHUD.show();
    String fileName = DateTime.now().millisecondsSinceEpoch.toString();
    UploadTask uploadTask = uploadFile(File(imageFile!.path), fileName);
    try {
      TaskSnapshot snapshot = await uploadTask;
      imageUrl = await snapshot.ref.getDownloadURL();
      setState(() {
        updateUserData(
            selectedCraftTypeID, twitter, instagram, about, imageUrl);
        Fluttertoast.showToast(msg: "تمت الاضافة بنجاح");
        SVProgressHUD.dismiss();
      });
    } on FirebaseException catch (e) {
      SVProgressHUD.dismiss();
      Fluttertoast.showToast(msg: e.message ?? e.toString());
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCrafts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: '',
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    getImage();
                  },
                  child: Container(
                    // padding: EdgeInsets.symmetric(horizontal: 14.w),
                    height: 100.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        border:
                            Border.all(color: Colors.grey.withOpacity(0.5))),
                    child: (imageFile != null)
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(15),
                            child: Image.file(
                              File(imageFile!.path),
                              fit: BoxFit.fill,
                              // height: 200.h,
                              width: double.infinity,
                            ),
                          )
                        : (userImageUrl != "")
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(15),
                                child: Image.network(
                                  userImageUrl,
                                  fit: BoxFit.fill,
                                  width: double.infinity,
                                ),
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Icon(
                                    Icons.image,
                                    size: 60,
                                    color: Colors.black,
                                  ),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  CustomText(
                                    text: "ارفق صورة الحساب",
                                    textColor: Colors.grey,
                                    fontSize: 13,
                                  ),
                                ],
                              ),
                  ),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.center,
                  children: [
                    CustomTextField(
                      labelTitle: "اختر نوع الحرفة",
                      initialValue: type,
                      labelHidden: true,
                      textInputAction: TextInputAction.next,
                      readOnly: true,
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        color: Colors.black,
                      ),
                      labelColor: Colors.black,
                      textAlign: TextAlign.right,
                      onSaved: (String? value) {
                        type = value ?? "";
                      },
                    ),
                    Column(
                      children: [
                        const SizedBox(
                          height: 35,
                        ),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: DropdownButton(
                              icon: const SizedBox(),
                              underline: const SizedBox(),
                              items: craftsType.map((items) {
                                return DropdownMenuItem<CraftTypesModel>(
                                  value: items,
                                  child: Text(items.title),
                                );
                              }).toList(),
                              onChanged: (val) {
                                setState(() {
                                  var index = craftsType.indexOf(val!);
                                  type = craftsType[index].title;
                                  selectedCraftTypeID = craftsType[index].uid;
                                });
                              }),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  controller: (about == null || about == "")
                      ? null
                      : TextEditingController(text: about),
                  onChanged: (val) {
                    about = val;
                  },
                  decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 0, color: Colors.grey),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "نبذة عن الحساب"),
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  controller: (twitter == null || twitter == "")
                      ? null
                      : TextEditingController(text: twitter),
                  onChanged: (val) {
                    twitter = val;
                  },
                  decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 0, color: Colors.grey),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: " رابط تويتر"),
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  controller: (instagram == null || instagram == "")
                      ? null
                      : TextEditingController(text: instagram),
                  onChanged: (val) {
                    instagram = val;
                  },
                  decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 0, color: Colors.grey),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "رابط الانستاغرام"),
                ),
                SizedBox(
                  height: 15.h,
                ),
                InkWell(
                  onTap: () {
                    Get.to(() => AddProductImagesScreen());
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 14.w),
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(
                            color:
                                Assets.shared.primaryColor.withOpacity(0.5))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        CustomText(
                          text: "أرفق صور المنتجات",
                          textColor: Colors.black,
                          fontSize: 13,
                        ),
                        Expanded(child: SizedBox()),
                        Icon(
                          Icons.arrow_forward,
                          size: 25,
                          color: Colors.black,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 15.h,
                ),
                InkWell(
                  onTap: () {
                    Get.to(() => AddCourseScreen());
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 14.w),
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(
                            color:
                                Assets.shared.primaryColor.withOpacity(0.5))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        CustomText(
                          text: "ارفق دورة او ورشة عمل",
                          textColor: Colors.black,
                          fontSize: 13,
                        ),
                        Expanded(child: SizedBox()),
                        Icon(
                          Icons.arrow_forward,
                          size: 25,
                          color: Colors.black,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20.h,
                ),
                MainButton(
                  title: "حفظ",
                  backgroundColor: Assets.shared.primaryColor,
                  onPressed: () {
                    if (imageFile != null) {
                      uploadImage();
                    } else {
                      updateUserData(selectedCraftTypeID, twitter, instagram,
                          about, userImageUrl);
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
