import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/craft_model.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class HerfyDetailsScreen extends StatefulWidget {
  CraftModel craft;
  HerfyDetailsScreen({Key? key, required this.craft}) : super(key: key);

  @override
  State<HerfyDetailsScreen> createState() => _HerfyDetailsScreenState();
}

class _HerfyDetailsScreenState extends State<HerfyDetailsScreen> {
  void openUrl(String url) async {
    if (await canLaunchUrlString(url)) {
      await launchUrlString(url);
    } else {
      throw 'Could not launch ${url}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.craft.title,
          style: const TextStyle(color: Colors.black),
        ),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                height: 8.h,
              ),
              Container(
                height: 180,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: widget.craft.imageUrl == ""
                      ? Image.asset(
                          Assets.shared.imgCraft,
                          fit: BoxFit.fill,
                        )
                      : Image.network(
                          widget.craft.imageUrl ?? "",
                          fit: BoxFit.fill,
                        ),
                ),
              ),
              SizedBox(
                height: 15.h,
              ),
              CustomText(
                text: widget.craft.details,
                fontWeight: FontWeight.bold,
                fontSize: 20,
                alignment: Alignment.centerRight,
                textAlign: TextAlign.right,
              ),
              SizedBox(
                height: 15.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  MainButton(
                    title: "شراء",
                    onPressed: () {
                      openUrl(widget.craft.craftUrl ?? "");
                    },
                    backgroundColor: Assets.shared.primaryColor,
                  )
                ],
              ),
              SizedBox(
                height: 15.h,
              ),
              Container(
                color: Colors.black,
                height: 1,
              ),
              SizedBox(
                height: 15.h,
              ),
              const CustomText(
                text: "منتجات ذات صلة",
                fontWeight: FontWeight.bold,
                fontSize: 15,
                alignment: Alignment.centerRight,
                textAlign: TextAlign.right,
              ),
              SizedBox(
                height: 15.h,
              ),
              Container(
                  height: 150,
                  child: FutureBuilder(
                      future:
                          getCraftsByCraftTypeId(widget.craft.craftId ?? ""),
                      builder:
                          (context, AsyncSnapshot<List<CraftModel>> snapshot) {
                        if (snapshot.hasData) {
                          return ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: snapshot.data?.length ?? 0,
                              itemBuilder: (context, index) {
                                return Container(
                                  margin: EdgeInsets.symmetric(horizontal: 8),
                                  width: 120,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15)),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(15),
                                      child: Image.network(
                                        snapshot.data?[index].imageUrl ?? "",
                                        fit: BoxFit.fill,
                                      )),
                                );
                              });
                        } else if (snapshot.hasError) {
                          return SizedBox();
                        } else {
                          return SizedBox();
                        }
                      })),
            ],
          ),
        ),
      ),
    );
  }
}
