import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:herfatek/custom_widgets/custom_text.dart';
import 'package:herfatek/model/courses_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:herfatek/utils/assets.dart';
import 'package:herfatek/views/course_details_screen.dart';

import '../custom_widgets/custom_text_field.dart';

class CoursesScreen extends StatefulWidget {
  CoursesScreen({Key? key}) : super(key: key);

  @override
  _CoursesScreenState createState() => _CoursesScreenState();
}

class _CoursesScreenState extends State<CoursesScreen> {
  String type = "";

  List<String> types = ["اختر", "دورة", "ورشة عمل"];

  String searchTxt = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "الدورات وورش العمل",
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 8.h,
            ),
            TextFormField(
              onFieldSubmitted: (val) {
                setState(() {});
                print("submit");
              },
              onChanged: (val) {
                searchTxt = val;
              },
              decoration: InputDecoration(
                  isDense: true,
                  suffixIcon: const Icon(
                    Icons.search,
                    color: Colors.black,
                  ),
                  prefixIconConstraints:
                      BoxConstraints(minWidth: 0, minHeight: 0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 0, color: Colors.grey),
                    borderRadius: BorderRadius.circular(25.0),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25.0),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  hintText: "بحث"),
            ),
            // SizedBox(
            //   height: 8.h,
            // ),
            Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                CustomTextField(
                  labelTitle: "اختر النوع",
                  labelHidden: true,
                  initialValue: type,
                  textInputAction: TextInputAction.next,
                  readOnly: true,
                  icon: const Icon(
                    Icons.keyboard_arrow_down,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    type = value ?? "";
                  },
                ),
                Column(
                  children: [
                    const SizedBox(
                      height: 35,
                    ),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: DropdownButton(
                          icon: const SizedBox(),
                          underline: const SizedBox(),
                          items: types.map((items) {
                            return DropdownMenuItem<String>(
                              value: items,
                              child: Text(items),
                            );
                          }).toList(),
                          onChanged: (val) {
                            var index = types.indexOf(val!);
                            type = types[index];
                            print(type);
                            setState(() {});
                          }),
                    ),
                  ],
                ),
              ],
            ),
            // Row(
            //   children: [
            //     Expanded(
            //       child: TextFormField(
            //         decoration: InputDecoration(
            //             isDense: true,
            //             suffixIcon: const Icon(
            //               Icons.arrow_drop_down_sharp,
            //               color: Colors.black,
            //             ),
            //             prefixIconConstraints:
            //                 BoxConstraints(minWidth: 0, minHeight: 0),
            //             enabledBorder: OutlineInputBorder(
            //               borderSide: BorderSide(width: 0, color: Colors.grey),
            //               borderRadius: BorderRadius.circular(25.0),
            //             ),
            //             border: OutlineInputBorder(
            //               borderRadius: BorderRadius.circular(25.0),
            //             ),
            //             filled: true,
            //             fillColor: Colors.white,
            //             hintText: "نوع الحرفة"),
            //       ),
            //     ),
            //     const SizedBox(
            //       width: 15,
            //     ),
            //     Expanded(
            //       child: TextFormField(
            //         decoration: InputDecoration(
            //             isDense: true,
            //             suffixIcon: const Icon(
            //               Icons.arrow_drop_down_sharp,
            //               color: Colors.black,
            //             ),
            //             prefixIconConstraints:
            //                 BoxConstraints(minWidth: 0, minHeight: 0),
            //             enabledBorder: OutlineInputBorder(
            //               borderSide: BorderSide(width: 0, color: Colors.grey),
            //               borderRadius: BorderRadius.circular(25.0),
            //             ),
            //             border: OutlineInputBorder(
            //               borderRadius: BorderRadius.circular(25.0),
            //             ),
            //             filled: true,
            //             fillColor: Colors.white,
            //             hintText: "دورات او ورش"),
            //       ),
            //     ),
            //   ],
            // ),
            SizedBox(
              height: 15.h,
            ),
            Expanded(
              child: FutureBuilder(
                  future: getCourses(),
                  builder:
                      (context, AsyncSnapshot<List<CoursesModel>> snapshot) {
                    if (snapshot.hasData) {
                      return GridView.count(
                        crossAxisCount: 2,
                        children: List.generate(
                            snapshot.data?.where((element) {
                                  if (type == 'دورة') {
                                    return element.type == "course" &&
                                        element.title.contains(searchTxt);
                                  } else if (type == 'ورشة عمل') {
                                    return element.type == "workshop" &&
                                        element.title.contains(searchTxt);
                                  } else {
                                    return element.type == element.type &&
                                        element.title.contains(searchTxt);
                                  }
                                }).length ??
                                0, (index) {
                          return InkWell(
                            onTap: () {
                              Get.to(
                                () => CourseDetailsScreen(
                                  course: snapshot.data!.where((element) {
                                    if (type == 'دورة') {
                                      return element.type == "course" &&
                                          element.title.contains(searchTxt);
                                    } else if (type == 'ورشة عمل') {
                                      return element.type == "workshop" &&
                                          element.title.contains(searchTxt);
                                    } else {
                                      return element.type == element.type &&
                                          element.title.contains(searchTxt);
                                    }
                                  }).toList()[index],
                                ),
                              );
                            },
                            child: Container(
                              margin: const EdgeInsets.symmetric(
                                  vertical: 10, horizontal: 10),
                              height: 135,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    spreadRadius: 0,
                                    blurRadius: 3,
                                    offset: Offset(
                                        0, 3), // changes position of shadow
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Stack(
                                    children: [
                                      Container(
                                        height: 124,
                                        decoration: BoxDecoration(
                                          // color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(12),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          child: Image.network(
                                            snapshot.data
                                                    ?.where((element) {
                                                      if (type == 'دورة') {
                                                        return element.type ==
                                                                "course" &&
                                                            element.title
                                                                .contains(
                                                                    searchTxt);
                                                      } else if (type ==
                                                          'ورشة عمل') {
                                                        return element.type ==
                                                                "workshop" &&
                                                            element.title
                                                                .contains(
                                                                    searchTxt);
                                                      } else {
                                                        return element.type ==
                                                                element.type &&
                                                            element.title
                                                                .contains(
                                                                    searchTxt);
                                                      }
                                                    })
                                                    .toList()[index]
                                                    .imageUrl ??
                                                "",
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        top: 10,
                                        right: 16,
                                        child: Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 8),
                                          width: 60,
                                          height: 20,
                                          decoration: BoxDecoration(
                                              color:
                                                  Colors.black.withOpacity(0.6),
                                              borderRadius:
                                                  BorderRadius.circular(12)),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: const [
                                              CustomText(
                                                text: "4.5",
                                                fontSize: 10,
                                                textColor: Colors.white,
                                              ),
                                              SizedBox(
                                                width: 8,
                                              ),
                                              Icon(
                                                Icons.star,
                                                color: Colors.amber,
                                                size: 15,
                                              )
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  Expanded(
                                    child: Center(
                                      child: Text(
                                        snapshot.data
                                                ?.where((element) {
                                                  if (type == 'دورة') {
                                                    return element.type ==
                                                            "course" &&
                                                        element.title.contains(
                                                            searchTxt);
                                                  } else if (type ==
                                                      'ورشة عمل') {
                                                    return element.type ==
                                                            "workshop" &&
                                                        element.title.contains(
                                                            searchTxt);
                                                  } else {
                                                    return element.type ==
                                                            element.type &&
                                                        element.title.contains(
                                                            searchTxt);
                                                  }
                                                })
                                                .toList()[index]
                                                .title ??
                                            "",
                                        textAlign: TextAlign.right,
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 16),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                      );
                    } else if (snapshot.hasError) {
                      return const SizedBox();
                    } else {
                      return Center(
                        child: SizedBox(
                          width: 50,
                          height: 50,
                          child: CircularProgressIndicator(
                            color: Assets.shared.primaryColor,
                          ),
                        ),
                      );
                    }
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
