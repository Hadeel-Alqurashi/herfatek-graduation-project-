import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:herfatek/model/user_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/courses_model.dart';
import '../utils/assets.dart';

class CourseDetailsScreen extends StatefulWidget {
  CoursesModel course;

  CourseDetailsScreen({Key? key, required this.course}) : super(key: key);

  @override
  State<CourseDetailsScreen> createState() => _CourseDetailsScreenState();
}

class _CourseDetailsScreenState extends State<CourseDetailsScreen> {
  UserModel? _user;

  void fetchUser() async {
    _user = await getUserByUid(widget.course.userUid ?? "");
    setState(() {});
  }

  void openUrl(String url) async {
    if (await canLaunchUrlString(url)) {
      await launchUrlString(url);
    } else {
      throw 'Could not launch ${url}';
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "الدورات وورش العمل",
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                height: 8.h,
              ),
              Container(
                margin:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                height: 200,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 0,
                      blurRadius: 3,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      height: 120,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        // color: Colors.red,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          widget.course.imageUrl ?? "",
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              widget.course.title,
                              textAlign: TextAlign.right,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16),
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                    CustomText(
                                      text: "4.5",
                                      fontSize: 10,
                                      textColor: Colors.black,
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.amber,
                                      size: 15,
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  width: 50,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                    CustomText(
                                      text: "1 h 50 m",
                                      fontSize: 10,
                                      textColor: Colors.black,
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    Icon(
                                      Icons.timer,
                                      color: Colors.black,
                                      size: 15,
                                    )
                                  ],
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 15.h,
              ),
              Row(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(40),
                      child: (_user?.userImageUrl != null)
                          ? Image.network(
                              _user?.userImageUrl ?? "",
                              fit: BoxFit.fill,
                            )
                          : SizedBox(),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: _user?.name ?? "",
                        textColor: Assets.shared.primaryColor,
                        fontSize: 14,
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      CustomText(
                        text: _user?.about ?? "",
                        textColor: Assets.shared.primaryColor,
                        fontSize: 14,
                      ),
                    ],
                  ),
                  const Expanded(
                    child: SizedBox(),
                  ),
                  const Icon(
                    Icons.favorite,
                    color: Colors.red,
                    size: 30,
                  ),
                ],
              ),
              SizedBox(
                height: 15.h,
              ),
              CustomText(
                text: widget.course.title,
                textColor: Colors.black,
                alignment: Alignment.bottomRight,
              ),
              SizedBox(
                height: 8.h,
              ),
              CustomText(
                text: widget.course.details,
                textColor: Colors.black,
                alignment: Alignment.bottomRight,
              ),
              SizedBox(
                height: 20.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  MainButton(
                    title: "انقر للتسجيل",
                    onPressed: () {
                      openUrl(widget.course.url ?? "");
                    },
                    backgroundColor: Assets.shared.primaryColor,
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
