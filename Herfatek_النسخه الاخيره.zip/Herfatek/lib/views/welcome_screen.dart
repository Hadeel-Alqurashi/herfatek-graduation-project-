import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:herfatek/custom_widgets/custom_text.dart';
import 'package:herfatek/custom_widgets/main_button.dart';
import 'package:herfatek/views/sign_in_screen.dart';
import 'package:herfatek/views/sign_up_screen.dart';

import '../../utils/assets.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        color: Colors.white,
        child: Column(
          children: [
            const SizedBox(
              height: 100,
            ),
            Image.asset(
              Assets.shared.icLogo,
              width: 300.r,
              height: 300.r,
            ),
            const SizedBox(
              height: 40,
            ),
            const CustomText(
              text: "مرحباً بكم في تطبيق حرفتك",
              fontSize: 30,
              fontWeight: FontWeight.bold,
              textColor: Colors.black,
            ),
            const SizedBox(
              height: 20,
            ),
            const CustomText(
              text:
                  "هنا تتعلم الكثير من الحرف اليدوية وتتعرف على ا لحرفيين وجميعها باللغة العربية",
              fontSize: 15,
              textColor: Colors.grey,
            ),
            const SizedBox(
              height: 30,
            ),
            MainButton(
              title: "تسجيل الدخول",
              backgroundColor: Assets.shared.primaryColor,
              onPressed: () {
                Get.to(() => LoginScreen());
              },
            ),
            const SizedBox(
              height: 20,
            ),
            MainButton(
              title: "انشاء حساب",
              backgroundColor: Assets.shared.primaryColor,
              onPressed: () {
                Get.to(() => SignUpScreen());
              },
            ),
          ],
        ),
      ),
    );
  }
}
