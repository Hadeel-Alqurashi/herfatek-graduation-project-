import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:herfatek/views/custom_tab_bar.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/craft_types_model.dart';
import '../model/status_response.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';
import 'continue_herfy_info_screen.dart';

class SignUpScreen extends StatefulWidget {
  SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  String email = "";
  String password = "";
  String confirmPassword = "";
  String userName = "";
  String name = "";
  String type = "";
  String twitter = "";
  String instagram = "";

  String selectedCraftTypeID = "";

  var isHerfy = false;
  List<CraftTypesModel> craftsType = [];

  Future<void> performSignUp() async {
    if (email == "" || name == "" || password == "" || userName == "") {
      Fluttertoast.showToast(msg: "الرجاء ملئ جميع الحقول");
    } else {
      if (password != confirmPassword) {
        Fluttertoast.showToast(msg: "كلمة المرور غير متطابقة");
        return;
      }

      if (isHerfy && type == "") {
        Fluttertoast.showToast(msg: "الرجاء اختيار الحرفة");
        return;
      }

      StatusResponse status = await createFireUser(
        email,
        name,
        userName,
        password,
        isHerfy ? "1" : "0",
        selectedCraftTypeID,
        twitter,
        instagram,
      );
      print(status);

      if (status != null) {
        Fluttertoast.showToast(msg: status.message);
        if (status.status) {
          Get.offAll(
            () => CustomTabBar(),
          );
        }
      } else {}
    }
  }

  void fetchCrafts() async {
    List<CraftTypesModel> types = await getCraftsTypes();
    setState(() {
      craftsType = types;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCrafts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'انشاء حساب',
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 15.h,
                ),
                CustomTextField(
                  labelTitle: "ادخل الاسم",
                  textInputAction: TextInputAction.next,
                  icon: const Icon(
                    Icons.margin,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    name = value ?? "";
                  },
                ),
                SizedBox(
                  height: 15.h,
                ),
                CustomTextField(
                  labelTitle: "ادخل البريد الالكتروني",
                  textInputAction: TextInputAction.next,
                  icon: const Icon(
                    Icons.email,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    email = value ?? "";
                  },
                ),
                SizedBox(
                  height: 15.h,
                ),
                CustomTextField(
                  labelTitle: "ادخل اسم المستخدم",
                  textInputAction: TextInputAction.next,
                  icon: const Icon(
                    Icons.person,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    userName = value ?? "";
                  },
                ),
                SizedBox(
                  height: 15.h,
                ),
                CustomTextField(
                  labelTitle: "ادخل كلمة المرور",
                  textInputAction: TextInputAction.next,
                  icon: const Icon(
                    Icons.key,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    password = value ?? "";
                  },
                ),
                SizedBox(
                  height: 15.h,
                ),
                CustomTextField(
                  labelTitle: "اعد كتابة كلمة المرور",
                  textInputAction: TextInputAction.next,
                  icon: const Icon(
                    Icons.key,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    confirmPassword = value ?? "";
                  },
                ),
                SizedBox(
                  height: 8.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () {
                        // Get.to(() => ForgotPasswordView());
                      },
                      child: const CustomText(
                        text: "هل تريد انشاء ا لحساب كحرفي ؟",
                        fontWeight: FontWeight.normal,
                        fontSize: 12,
                        textColor: Colors.black,
                      ),
                    ),
                    Checkbox(
                        value: isHerfy,
                        activeColor: Colors.black,
                        onChanged: (val) {
                          isHerfy = !isHerfy;
                          setState(() {});
                        }),
                  ],
                ),
                isHerfy
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          SizedBox(
                            height: 15.h,
                          ),
                          Stack(
                            clipBehavior: Clip.none,
                            alignment: Alignment.center,
                            children: [
                              CustomTextField(
                                labelTitle: "اختر نوع الحرفة",
                                initialValue: type,
                                textInputAction: TextInputAction.next,
                                readOnly: true,
                                icon: const Icon(
                                  Icons.keyboard_arrow_down,
                                  color: Colors.black,
                                ),
                                labelColor: Colors.black,
                                textAlign: TextAlign.right,
                                onSaved: (String? value) {
                                  type = value ?? "";
                                },
                              ),
                              Column(
                                children: [
                                  const SizedBox(
                                    height: 35,
                                  ),
                                  SizedBox(
                                    width: double.infinity,
                                    height: 50,
                                    child: DropdownButton(
                                        icon: const SizedBox(),
                                        underline: const SizedBox(),
                                        items: craftsType.map((items) {
                                          return DropdownMenuItem<
                                              CraftTypesModel>(
                                            value: items,
                                            child: Text(items.title),
                                          );
                                        }).toList(),
                                        onChanged: (val) {
                                          setState(() {
                                            var index =
                                                craftsType.indexOf(val!);
                                            type = craftsType[index].title;
                                            selectedCraftTypeID =
                                                craftsType[index].uid;
                                          });
                                        }),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          const CustomText(
                            textColor: Colors.black,
                            fontSize: 13,
                            text: "ضم مواقع التواصل الاجتماعي لحسابك التجاري",
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          InkWell(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (_) => AlertDialog(
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(12.0),
                                    ),
                                  ),
                                  content: Builder(
                                    builder: (context) {
                                      return SizedBox(
                                        height: 200,
                                        // width: width -
                                        //     10,
                                        child: Column(
                                          children: [
                                            const SizedBox(
                                              height: 8,
                                            ),
                                            const CustomText(
                                              text: "الرجاء لصق الرابط",
                                              textColor: Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            const SizedBox(
                                              height: 25,
                                            ),
                                            CustomTextField(
                                              labelTitle: "رابط تويتر",
                                              textInputAction:
                                                  TextInputAction.next,
                                              labelColor: Colors.black,
                                              textAlign: TextAlign.right,
                                              onSaved: (String? value) {
                                                twitter = value ?? "";
                                              },
                                            ),
                                            const SizedBox(
                                              height: 8,
                                            ),
                                            MainButton(
                                              title: "حفظ",
                                              backgroundColor:
                                                  Assets.shared.primaryColor,
                                              onPressed: () {
                                                Navigator.pop(context);
                                                setState(() {});
                                              },
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 14.w),
                              height: 50,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(25),
                                  border: Border.all(
                                      color: Colors.grey.withOpacity(0.5))),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  const CustomText(
                                    text: "Twitter",
                                    textColor: Colors.black,
                                    fontSize: 13,
                                  ),
                                  const SizedBox(
                                    width: 15,
                                  ),
                                  Image.asset(
                                    Assets.shared.icTwitter,
                                    width: 25,
                                    height: 25,
                                  ),
                                  const Expanded(
                                    child: SizedBox(),
                                  ),
                                  twitter == ""
                                      ? SizedBox()
                                      : const CustomText(
                                          text: "تم الاختيار",
                                          textColor: Colors.black,
                                          fontSize: 13,
                                        ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          InkWell(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (_) => AlertDialog(
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(12.0),
                                    ),
                                  ),
                                  content: Builder(
                                    builder: (context) {
                                      return SizedBox(
                                        height: 200,
                                        // width: width -
                                        //     10,
                                        child: Column(
                                          children: [
                                            const SizedBox(
                                              height: 8,
                                            ),
                                            const CustomText(
                                              text: "الرجاء لصق الرابط",
                                              textColor: Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            const SizedBox(
                                              height: 25,
                                            ),
                                            CustomTextField(
                                              labelTitle: "رابط الانستغرام",
                                              textInputAction:
                                                  TextInputAction.next,
                                              labelColor: Colors.black,
                                              textAlign: TextAlign.right,
                                              onSaved: (String? value) {
                                                instagram = value ?? "";
                                              },
                                            ),
                                            const SizedBox(
                                              height: 8,
                                            ),
                                            MainButton(
                                              title: "حفظ",
                                              backgroundColor:
                                                  Assets.shared.primaryColor,
                                              onPressed: () {
                                                Navigator.pop(context);
                                                setState(() {});
                                              },
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 14.w),
                              height: 50,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(25),
                                  border: Border.all(
                                      color: Colors.grey.withOpacity(0.5))),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  const CustomText(
                                    text: "Instagram",
                                    textColor: Colors.black,
                                    fontSize: 13,
                                  ),
                                  const SizedBox(
                                    width: 15,
                                  ),
                                  Image.asset(
                                    Assets.shared.icInstagram,
                                    width: 25,
                                    height: 25,
                                  ),
                                  const Expanded(
                                    child: SizedBox(),
                                  ),
                                  instagram == ""
                                      ? SizedBox()
                                      : const CustomText(
                                          text: "تم الاختيار",
                                          textColor: Colors.black,
                                          fontSize: 13,
                                        ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : const SizedBox(),
                SizedBox(
                  height: 20.h,
                ),
                MainButton(
                  title: "انشاء الحساب",
                  backgroundColor: Assets.shared.primaryColor,
                  onPressed: () {
                    // Get.to(() => ContinueHerfyInfoScreen());
                    performSignUp();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
