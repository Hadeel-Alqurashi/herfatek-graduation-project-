import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:herfatek/model/user_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/craft_model.dart';
import '../utils/assets.dart';

class HerfyProfileScreen extends StatefulWidget {
  UserModel user;
  HerfyProfileScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<HerfyProfileScreen> createState() => _HerfyProfileScreenState();
}

class _HerfyProfileScreenState extends State<HerfyProfileScreen> {
  void openUrl(String url) async {
    if (await canLaunchUrlString(url)) {
      await launchUrlString(url);
    } else {
      throw 'Could not launch ${url}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.user.name ?? "",
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 8.h,
            ),
            // Container(
            //   height: 180,
            //   child: Image.asset(
            //     Assets.shared.imgCraft2,
            //     fit: BoxFit.fill,
            //   ),
            // ),
            // SizedBox(
            //   height: 15.h,
            // ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Row(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: (widget.user.userImageUrl == null)
                          ? Image.asset(
                              Assets.shared.imgUser2,
                              width: 30,
                              height: 30,
                            )
                          : Image.network(
                              widget.user.userImageUrl ?? "",
                              width: 30,
                              height: 30,
                              fit: BoxFit.fill,
                            ),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  CustomText(
                    text: widget.user.name ?? "",
                    textColor: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 15.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: CustomText(
                text: widget.user.about ?? "",
                textColor: Colors.black,
                alignment: Alignment.centerRight,
                textAlign: TextAlign.right,
              ),
            ),
            SizedBox(
              height: 15.h,
            ),
            Container(
              height: 1,
              color: Colors.black,
            ),
            SizedBox(
              height: 15.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: const CustomText(
                text: "روابط",
                textColor: Colors.black,
                fontWeight: FontWeight.bold,
                alignment: Alignment.centerRight,
                textAlign: TextAlign.right,
              ),
            ),
            SizedBox(
              height: 15.h,
            ),
            InkWell(
              onTap: () {
                openUrl(widget.user.twitterUrl ?? "");
              },
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Row(
                  children: [
                    Image.asset(
                      Assets.shared.icTwitter,
                      width: 25,
                      height: 25,
                    ),
                    const SizedBox(
                      width: 15,
                    ),
                    const CustomText(
                      text: "",
                      textColor: Colors.black,
                      alignment: Alignment.centerRight,
                      textAlign: TextAlign.right,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 15.h,
            ),
            InkWell(
              onTap: () {
                openUrl(widget.user.instagramUrl ?? "");
              },
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Row(
                  children: [
                    Image.asset(
                      Assets.shared.icInstagram,
                      width: 25,
                      height: 25,
                    ),
                    const SizedBox(
                      width: 15,
                    ),
                    const CustomText(
                      text: "",
                      textColor: Colors.black,
                      alignment: Alignment.centerRight,
                      textAlign: TextAlign.right,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 15.h,
            ),
            Container(
              height: 1,
              color: Colors.black,
            ),
            SizedBox(
              height: 15.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  MainButton(
                    title: "المنتجات",
                    onPressed: () {},
                    backgroundColor: Assets.shared.primaryColor,
                  )
                ],
              ),
            ),
            SizedBox(
              height: 15.h,
            ),
            Container(
                height: 150,
                child: FutureBuilder(
                    future: getCraftsByUserId(widget.user.uid),
                    builder:
                        (context, AsyncSnapshot<List<CraftModel>> snapshot) {
                      if (snapshot.hasData) {
                        return ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: snapshot.data?.length ?? 0,
                            itemBuilder: (context, index) {
                              return Container(
                                margin: EdgeInsets.symmetric(horizontal: 8),
                                width: 120,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15)),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(15),
                                    child: Image.network(
                                      snapshot.data?[index].imageUrl ?? "",
                                      fit: BoxFit.fill,
                                    )),
                              );
                            });
                      } else if (snapshot.hasError) {
                        return SizedBox();
                      } else {
                        return SizedBox();
                      }
                    })),
          ],
        ),
      ),
    );
  }
}
