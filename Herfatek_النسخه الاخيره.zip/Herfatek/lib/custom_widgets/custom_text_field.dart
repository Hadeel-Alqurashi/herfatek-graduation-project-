import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/assets.dart';
import 'custom_text.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({
    Key? key,
    required this.labelTitle,
    this.initialValue,
    this.obscureText,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.done,
    this.readOnly = false,
    this.labelHidden = false,
    this.textAlign,
    this.labelAlign,
    this.labelAlignment,
    this.labelColor,
    this.textFiledColor,
    this.icon,
    required this.onSaved,
  }) : super(key: key);

  final String labelTitle;
  final String? initialValue;
  final bool? obscureText;
  final TextInputType textInputType;
  final TextInputAction textInputAction;
  final Function(String?) onSaved;
  final TextAlign? textAlign;
  final TextAlign? labelAlign;
  final Alignment? labelAlignment;
  final Color? labelColor;
  final Color? textFiledColor;
  final bool readOnly;
  final bool labelHidden;
  final Widget? icon;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        labelHidden
            ? SizedBox()
            : Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: CustomText(
                  text: labelTitle,
                  fontWeight: FontWeight.normal,
                  fontSize: 14,
                  textColor: labelColor ?? Assets.shared.primaryColor,
                  alignment: labelAlignment ?? Alignment.centerRight,
                  textAlign: labelAlign ?? TextAlign.right,
                ),
              ),
        labelHidden
            ? SizedBox()
            : SizedBox(
                height: 12.h,
              ),
        TextFormField(
          controller: initialValue == null
              ? null
              : TextEditingController(text: initialValue),
          obscureText: obscureText ?? false,
          textAlign: textAlign ?? TextAlign.center,
          readOnly: readOnly,
          textInputAction: textInputAction,
          keyboardType: textInputType,
          onChanged: (value) => onSaved(value),
          decoration: InputDecoration(
              isDense: true,
              suffixIcon: icon ?? SizedBox(),
              prefixIconConstraints: BoxConstraints(minWidth: 0, minHeight: 0),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 0, color: Colors.grey),
                borderRadius: BorderRadius.circular(25.0),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(25.0),
              ),
              filled: true,
              fillColor: textFiledColor ?? Colors.white,
              hintText: labelTitle),
        ),
      ],
    );
  }
}
