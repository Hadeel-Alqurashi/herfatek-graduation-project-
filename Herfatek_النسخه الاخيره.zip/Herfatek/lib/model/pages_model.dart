import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class PagesModel {
  String uid;
  String txt;
  String type;

  PagesModel({
    required this.uid,
    required this.txt,
    required this.type,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathCraftUid: uid,
        FirebaseConstants.pathTxt: txt,
        FirebaseConstants.pathType: type,
      };

  factory PagesModel.fromJson(Map<String, dynamic> json) => PagesModel(
        uid: json[FirebaseConstants.pathCraftUid],
        txt: json[FirebaseConstants.pathTxt],
        type: json[FirebaseConstants.pathType],
      );

  factory PagesModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String txt = "";
    String type = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      txt = doc.get(FirebaseConstants.pathTxt);
    } catch (e) {}

    try {
      type = doc.get(FirebaseConstants.pathType);
    } catch (e) {}

    return PagesModel(
      uid: uid,
      txt: txt,
      type: type,
    );
  }
}
