import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class CraftTypesModel {
  String uid;
  String title;
  String imgUrl;

  CraftTypesModel({
    required this.uid,
    required this.title,
    required this.imgUrl,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathCraftUid: uid,
        FirebaseConstants.pathCraftTitle: title,
        FirebaseConstants.pathCraftTypeImg: imgUrl,
      };

  factory CraftTypesModel.fromJson(Map<String, dynamic> json) =>
      CraftTypesModel(
        uid: json[FirebaseConstants.pathCraftUid],
        title: json[FirebaseConstants.pathCraftTitle],
        imgUrl: json[FirebaseConstants.pathCraftTypeImg],
      );

  factory CraftTypesModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String title = "";
    String imgUrl = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      title = doc.get(FirebaseConstants.pathCraftTitle);
    } catch (e) {}

    try {
      imgUrl = doc.get(FirebaseConstants.pathCraftTypeImg);
    } catch (e) {}

    return CraftTypesModel(
      uid: uid,
      title: title,
      imgUrl: imgUrl,
    );
  }
}
