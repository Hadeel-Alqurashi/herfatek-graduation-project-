import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class CraftModel {
  String uid;
  String title;
  String details;
  String? imageUrl;
  String? cityId;
  String? craftId;
  String? craftUrl;

  CraftModel({
    required this.uid,
    required this.title,
    required this.details,
    required this.imageUrl,
    this.cityId,
    this.craftUrl,
    this.craftId,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathCraftUid: uid,
        FirebaseConstants.pathCraftTitle: title,
        FirebaseConstants.pathCraftDetails: details,
        FirebaseConstants.pathCraftImageUrl: imageUrl,
        FirebaseConstants.pathCityId: cityId,
        FirebaseConstants.pathCraftId: craftId,
        FirebaseConstants.pathCraftUrl: craftUrl,
      };

  factory CraftModel.fromJson(Map<String, dynamic> json) => CraftModel(
        uid: json[FirebaseConstants.pathCraftUid],
        title: json[FirebaseConstants.pathCraftTitle],
        details: json[FirebaseConstants.pathCraftDetails],
        imageUrl: json[FirebaseConstants.pathCraftImageUrl],
        cityId: json[FirebaseConstants.pathCityId],
        craftId: json[FirebaseConstants.pathCraftId],
        craftUrl: json[FirebaseConstants.pathCraftUrl],
      );

  factory CraftModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String title = "";
    String details = "";
    String imageUrl = "";
    String cityId = "";
    String craftId = "";
    String craftUrl = "";

    try {
      uid = doc.get(FirebaseConstants.pathUserUuid);
    } catch (e) {}

    try {
      title = doc.get(FirebaseConstants.pathCraftTitle);
    } catch (e) {}

    try {
      details = doc.get(FirebaseConstants.pathCraftDetails);
    } catch (e) {}

    try {
      imageUrl = doc.get(FirebaseConstants.pathCraftImageUrl);
    } catch (e) {}

    try {
      cityId = doc.get(FirebaseConstants.pathCityId);
    } catch (e) {
      // print(e.toString());
    }

    try {
      craftId = doc.get(FirebaseConstants.pathCraftId);
    } catch (e) {}

    try {
      craftUrl = doc.get(FirebaseConstants.pathCraftUrl);
    } catch (e) {}

    return CraftModel(
      uid: uid,
      title: title,
      details: details,
      imageUrl: imageUrl,
      cityId: cityId,
      craftId: craftId,
      craftUrl: craftUrl,
    );
  }
}
