import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:herfatek/custom_widgets/custom_text.dart';
import 'package:herfatek/custom_widgets/main_button.dart';
import 'package:herfatek/model/craft_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:herfatek/utils/assets.dart';
import 'package:herfatek/views/course_details_screen.dart';

import '../custom_widgets/custom_text_field.dart';
import '../model/craft_types_model.dart';
import 'herfy_details_screen.dart';

class PlacesScreen extends StatefulWidget {
  const PlacesScreen({Key? key}) : super(key: key);

  @override
  _PlacesScreenState createState() => _PlacesScreenState();
}

class _PlacesScreenState extends State<PlacesScreen> {
  List<CraftTypesModel> cityType = [];
  String selectedCityTypeID = "";
  String city = "";

  String type = "";
  String selectedCraftTypeID = "";
  List<CraftTypesModel> craftsType = [];
  var selectedCraftIndex = 0;

  CraftTypesModel? selectedCraft;
  CraftTypesModel? selectedCity;

  void fetchCities() async {
    List<CraftTypesModel> types = await getCities();
    setState(() {
      cityType.add(CraftTypesModel(uid: '0', title: "الجميع", imgUrl: ""));
      cityType.addAll(types);
      selectedCity = cityType[0];
    });
  }

  void fetchCrafts() async {
    List<CraftTypesModel> types = await getCraftsTypes();
    setState(() {
      craftsType.add(CraftTypesModel(uid: '0', title: "الجميع", imgUrl: ""));

      craftsType.addAll(types);
      selectedCraft = craftsType[0];
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCrafts();
    fetchCities();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "المنتجات",
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // SizedBox(
                //   width: 150.w,
                //   child: TextFormField(
                //     decoration: InputDecoration(
                //         isDense: true,
                //         suffixIcon: const Icon(
                //           Icons.arrow_drop_down_sharp,
                //           color: Colors.black,
                //         ),
                //         prefixIconConstraints:
                //             BoxConstraints(minWidth: 0, minHeight: 0),
                //         enabledBorder: OutlineInputBorder(
                //           borderSide: BorderSide(width: 0, color: Colors.grey),
                //           borderRadius: BorderRadius.circular(25.0),
                //         ),
                //         border: OutlineInputBorder(
                //           borderRadius: BorderRadius.circular(25.0),
                //         ),
                //         filled: true,
                //         fillColor: Colors.white,
                //         hintText: "المدينة"),
                //   ),
                // ),
                SizedBox(
                  width: 150.w,
                  child: Stack(
                    clipBehavior: Clip.none,
                    alignment: Alignment.center,
                    children: [
                      CustomTextField(
                        labelTitle: "المدينة",
                        initialValue: city,
                        labelHidden: true,
                        textInputAction: TextInputAction.next,
                        readOnly: true,
                        icon: const Icon(
                          Icons.keyboard_arrow_down,
                          color: Colors.black,
                        ),
                        labelColor: Colors.black,
                        textAlign: TextAlign.right,
                        onSaved: (String? value) {
                          city = value ?? "";
                        },
                      ),
                      Column(
                        children: [
                          const SizedBox(
                            height: 35,
                          ),
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: DropdownButton(
                                icon: const SizedBox(),
                                underline: const SizedBox(),
                                items: cityType.map((items) {
                                  return DropdownMenuItem<CraftTypesModel>(
                                    value: items,
                                    child: Text(items.title),
                                  );
                                }).toList(),
                                onChanged: (val) {
                                  setState(() {
                                    var index = cityType.indexOf(val!);
                                    city = cityType[index].title;
                                    selectedCityTypeID = cityType[index].uid;
                                    selectedCity = cityType[index];
                                  });
                                }),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                Container(
                  width: 150.w,
                  child: Stack(
                    children: [
                      TextFormField(
                        readOnly: true,
                        initialValue: selectedCraft?.title ?? "",
                        decoration: InputDecoration(
                            isDense: true,
                            suffixIcon: const Icon(
                              Icons.arrow_drop_down_sharp,
                              color: Colors.black,
                            ),
                            prefixIconConstraints:
                                BoxConstraints(minWidth: 0, minHeight: 0),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(width: 0, color: Colors.grey),
                              borderRadius: BorderRadius.circular(25.0),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25.0),
                            ),
                            filled: true,
                            fillColor: Colors.white,
                            hintText: "نوع الحرفة"),
                      ),
                      SizedBox(
                        width: 150.w,
                        child: InkWell(
                          onTap: () {
                            Get.bottomSheet(
                              StatefulBuilder(
                                builder: (BuildContext context,
                                    StateSetter setModalState) {
                                  return Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 10),
                                    decoration: const BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(15),
                                            topRight: Radius.circular(15))),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                      children: [
                                        const CustomText(
                                          text: "بحث بنوع الحرفة",
                                          fontWeight: FontWeight.bold,
                                          alignment: Alignment.centerRight,
                                          textAlign: TextAlign.right,
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        Expanded(
                                            child: ListView.builder(
                                                itemCount: craftsType.length,
                                                itemBuilder: (context, index) {
                                                  return InkWell(
                                                    onTap: () {
                                                      setState(() {
                                                        selectedCraftIndex =
                                                            index;
                                                      });

                                                      setModalState(() {
                                                        selectedCraftIndex =
                                                            index;
                                                      });
                                                    },
                                                    child: Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              bottom: 20),
                                                      child: Column(
                                                        children: [
                                                          Row(
                                                            children: [
                                                              Icon(
                                                                Icons
                                                                    .check_circle,
                                                                color: selectedCraftIndex ==
                                                                        index
                                                                    ? Assets
                                                                        .shared
                                                                        .primaryColor
                                                                    : Colors
                                                                        .grey,
                                                              ),
                                                              const SizedBox(
                                                                width: 10,
                                                              ),
                                                              CustomText(
                                                                text: craftsType[
                                                                        index]
                                                                    .title,
                                                              )
                                                            ],
                                                          ),
                                                          const SizedBox(
                                                            height: 8,
                                                          ),
                                                          Container(
                                                            height: 1,
                                                            color: Colors.grey,
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  );
                                                })),
                                        MainButton(
                                          title: "اظهار النتائج",
                                          onPressed: () {
                                            selectedCraft =
                                                craftsType[selectedCraftIndex];

                                            setState(() {});
                                            Get.back(closeOverlays: true);
                                          },
                                          backgroundColor:
                                              Assets.shared.primaryColor,
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                          child: SizedBox(
                            width: 150.w,
                            height: 40,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 30.h,
            ),
            Expanded(
              child: FutureBuilder(
                  future: getCrafts(),
                  builder: (context, AsyncSnapshot<List<CraftModel>> snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data?.where((element) {
                              if (selectedCraft?.uid == '0' &&
                                  selectedCity?.uid == '0') {
                                return element.craftId == element.craftId;
                              } else if (selectedCraft?.uid == '0' &&
                                  selectedCity?.uid != '0') {
                                return element.cityId == selectedCity?.uid;
                              } else if (selectedCraft?.uid != '0' &&
                                  selectedCity?.uid == '0') {
                                return element.craftId == selectedCraft?.uid;
                              } else {
                                return (element.craftId ==
                                        selectedCraft?.uid) &&
                                    (element.cityId == selectedCity?.uid);
                              }
                            }).length ??
                            0,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: EdgeInsets.only(bottom: 20.h),
                            height: 150,

                            // color: Colors.red,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      CustomText(
                                        text: snapshot.data?[index].title ?? "",
                                        alignment: Alignment.bottomRight,
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          text: snapshot.data?[index].details ??
                                              "",
                                          fontSize: 13,
                                          alignment: Alignment.centerRight,
                                          textAlign: TextAlign.right,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 4,
                                      ),
                                      SizedBox(
                                        height: 40,
                                        child: MainButton(
                                          title: "تفاصيل الحرفة",
                                          fontSize: 12,
                                          onPressed: () {
                                            Get.to(() => HerfyDetailsScreen(
                                                craft: snapshot.data![index]));
                                          },
                                          backgroundColor:
                                              Assets.shared.primaryColor,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  height: 150,
                                  width: 180,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Colors.black,
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: Image.network(
                                      snapshot.data?[index].imageUrl ?? "",
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const SizedBox();
                    } else {
                      return Center(
                        child: Container(
                          width: 50,
                          height: 50,
                          child: CircularProgressIndicator(
                            color: Assets.shared.primaryColor,
                          ),
                        ),
                      );
                    }
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
