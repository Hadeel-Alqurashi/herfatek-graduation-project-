import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:herfatek/views/custom_tab_bar.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../model/status_response.dart';
import '../model/user_model.dart';
import '../services/firebase_constants.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  String email = "";
  String password = "";

  void performSignIn() async {
    if (email == "" || password == "") {
      Fluttertoast.showToast(msg: "الرجاء ملئ جميع الحقول");
    } else {
      StatusResponse response = await signInFireUser(email, password);
      if (response != null) {
        if (response.status) {
          final FirebaseAuth auth = FirebaseAuth.instance;
          final User? fireUser = auth.currentUser;
          final uid = fireUser!.uid;

          UserModel? user = await getCurrentUser(uid);
          if (user != null) {
            GetStorage box = GetStorage();
            box.write(FirebaseConstants.userStoragePath, user.toJson());
            Fluttertoast.showToast(msg: "تم تسجيل الدخول بنجاح");

            Get.offAll(
              () => CustomTabBar(),
            );
          }
        } else {
          Fluttertoast.showToast(msg: response.message);
        }
      } else {
        Fluttertoast.showToast(msg: "عذراً بيانات الدخول خاطئة");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: '',
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  Assets.shared.icLogo,
                  width: 200.r,
                  height: 200.r,
                ),
                SizedBox(
                  height: 20.h,
                ),
                CustomTextField(
                  labelTitle: "ادخل اسم المستخدم",
                  textInputAction: TextInputAction.next,
                  icon: const Icon(
                    Icons.person,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    email = value ?? "";
                  },
                ),
                SizedBox(
                  height: 15.h,
                ),
                CustomTextField(
                  labelTitle: "ادخل كلمة المرور",
                  textInputAction: TextInputAction.next,
                  obscureText: true,
                  icon: const Icon(
                    Icons.lock,
                    color: Colors.black,
                  ),
                  labelColor: Colors.black,
                  textAlign: TextAlign.right,
                  onSaved: (String? value) {
                    password = value ?? "";
                  },
                ),
                SizedBox(
                  height: 8.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () {
                        // Get.to(() => ForgotPasswordView());
                      },
                      child: const CustomText(
                        text: "نسيت كلمة المرور ؟",
                        fontWeight: FontWeight.normal,
                        fontSize: 12,
                        textColor: Colors.black,
                      ),
                    ),
                    Row(
                      children: [
                        const CustomText(
                          text: "تذكرني لاحقاً",
                          fontWeight: FontWeight.normal,
                          fontSize: 12,
                          textColor: Colors.black,
                        ),
                        Checkbox(
                            value: true,
                            activeColor: Colors.black,
                            onChanged: (val) {})
                      ],
                    )
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                MainButton(
                  title: "تسجيل الدخول",
                  backgroundColor: Assets.shared.primaryColor,
                  onPressed: () {
                    performSignIn();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
