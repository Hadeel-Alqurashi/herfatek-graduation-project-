import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:herfatek/custom_widgets/custom_text.dart';
import 'package:herfatek/custom_widgets/main_button.dart';
import 'package:herfatek/model/user_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:herfatek/utils/assets.dart';
import 'package:herfatek/views/continue_herfy_info_screen.dart';
import 'package:herfatek/views/pages_screen.dart';
import 'package:herfatek/views/welcome_screen.dart';

import '../services/firebase_constants.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  UserModel? _user;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _user = getLocalUser();
    print(_user);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "اعدادات الحساب",
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 15.h,
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              height: 80,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey),
                color: Colors.grey.withOpacity(0.07),
              ),
              child: Row(
                children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(25),
                      child: (_user?.userImageUrl == null ||
                              _user?.userImageUrl == "")
                          ? Image.asset(
                              Assets.shared.imgUser2,
                              width: 50,
                              height: 50,
                            )
                          : Image.network(
                              _user?.userImageUrl ?? "",
                              width: 50,
                              height: 50,
                              fit: BoxFit.fill,
                            )),
                  const SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: _user?.name ?? "",
                        alignment: Alignment.centerRight,
                        textAlign: TextAlign.right,
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      const CustomText(
                        text: "تعديل الملف الشخصي",
                        alignment: Alignment.centerRight,
                        fontSize: 14,
                        textAlign: TextAlign.right,
                      ),
                    ],
                  ),
                  const Expanded(
                    child: SizedBox(),
                  ),
                  InkWell(
                    onTap: () {
                      showDialog(
                          context: context,
                          builder: (_) => AlertDialog(
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(10.0))),
                                content: Builder(
                                  builder: (context) {
                                    var height =
                                        MediaQuery.of(context).size.height;
                                    var width =
                                        MediaQuery.of(context).size.width;
                                    var newName = "";
                                    return Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15, vertical: 10),
                                      height: 150,
                                      width: width - 60,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.stretch,
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              // CustomText(
                                              //   text: "الغاء",
                                              //   alignment:
                                              //       Alignment.centerRight,
                                              //   fontSize: 14,
                                              //   fontWeight: FontWeight.bold,
                                              //   textAlign: TextAlign.right,
                                              // ),
                                              const SizedBox(),
                                              InkWell(
                                                onTap: () async {
                                                  if (newName == "") {
                                                    Fluttertoast.showToast(
                                                        msg:
                                                            "الرجاء كتابةالاسم الجديد");
                                                    return;
                                                  }
                                                  updateUserName(newName);
                                                  final FirebaseAuth auth =
                                                      FirebaseAuth.instance;
                                                  final User? fireUser =
                                                      auth.currentUser;
                                                  final uid = fireUser!.uid;

                                                  UserModel? user =
                                                      await getCurrentUser(uid);
                                                  if (user != null) {
                                                    GetStorage box =
                                                        GetStorage();
                                                    box.write(
                                                        FirebaseConstants
                                                            .userStoragePath,
                                                        user.toJson());
                                                    _user = user;
                                                    setState(() {});
                                                  }
                                                },
                                                child: const CustomText(
                                                  text: "حفظ",
                                                  alignment:
                                                      Alignment.centerRight,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,
                                                  textAlign: TextAlign.right,
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 25,
                                          ),
                                          TextFormField(
                                            onChanged: (val) {
                                              newName = val;
                                            },
                                            decoration: InputDecoration(
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderSide: const BorderSide(
                                                      width: 0,
                                                      color: Colors.grey),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15.0),
                                                ),
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15.0),
                                                ),
                                                filled: true,
                                                fillColor: Colors.white,
                                                hintText: "الاسم"),
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          // TextFormField(
                                          //   decoration: InputDecoration(
                                          //       enabledBorder:
                                          //           OutlineInputBorder(
                                          //         borderSide: const BorderSide(
                                          //             width: 0,
                                          //             color: Colors.grey),
                                          //         borderRadius:
                                          //             BorderRadius.circular(
                                          //                 15.0),
                                          //       ),
                                          //       border: OutlineInputBorder(
                                          //         borderRadius:
                                          //             BorderRadius.circular(
                                          //                 15.0),
                                          //       ),
                                          //       filled: true,
                                          //       fillColor: Colors.white,
                                          //       hintText: "البريد الالكتروني"),
                                          // ),
                                          // const SizedBox(
                                          //   height: 10,
                                          // ),
                                          // TextFormField(
                                          //   decoration: InputDecoration(
                                          //       enabledBorder:
                                          //           OutlineInputBorder(
                                          //         borderSide: const BorderSide(
                                          //             width: 0,
                                          //             color: Colors.grey),
                                          //         borderRadius:
                                          //             BorderRadius.circular(
                                          //                 15.0),
                                          //       ),
                                          //       border: OutlineInputBorder(
                                          //         borderRadius:
                                          //             BorderRadius.circular(
                                          //                 15.0),
                                          //       ),
                                          //       filled: true,
                                          //       fillColor: Colors.white,
                                          //       hintText: "كلمة المرور"),
                                          // ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ));
                    },
                    child: const Icon(
                      Icons.edit,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 15.h,
            ),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              // height: 80,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey),
                color: Colors.grey.withOpacity(0.07),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _user?.isHerfy == "1"
                      ? InkWell(
                          onTap: () {
                            Get.to(
                              () => ContinueHerfyInfoScreen(),
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: const [
                                CustomText(
                                  text: "اعدادات صفحة الحرفي",
                                  alignment: Alignment.centerRight,
                                  textAlign: TextAlign.right,
                                ),
                                Icon(
                                  Icons.settings,
                                  color: Colors.black,
                                ),
                              ],
                            ),
                          ),
                        )
                      : SizedBox(),
                  SizedBox(
                    height: _user?.isHerfy == "1" ? 15 : 0,
                  ),
                  _user?.isHerfy == "1"
                      ? Container(
                          height: 1,
                          color: Colors.grey,
                        )
                      : SizedBox(),
                  const SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(
                          () => PagesScreen(type: "privacy", name: "الخصوصية"));
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          CustomText(
                            text: "الخصوصية",
                            alignment: Alignment.centerRight,
                            textAlign: TextAlign.right,
                          ),
                          Icon(
                            Icons.privacy_tip,
                            color: Colors.black,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    height: 1,
                    color: Colors.grey,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(() => PagesScreen(type: "safe", name: "الأمان"));
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          CustomText(
                            text: "الامان",
                            alignment: Alignment.centerRight,
                            textAlign: TextAlign.right,
                          ),
                          Icon(
                            Icons.lock,
                            color: Colors.black,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    height: 1,
                    color: Colors.grey,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(() => PagesScreen(type: "help", name: "مساعدة"));
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          CustomText(
                            text: "مساعدة",
                            alignment: Alignment.centerRight,
                            textAlign: TextAlign.right,
                          ),
                          Icon(
                            Icons.help,
                            color: Colors.black,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    height: 1,
                    color: Colors.grey,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(() => PagesScreen(type: "about", name: "حول"));
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          CustomText(
                            text: "حول",
                            alignment: Alignment.centerRight,
                            textAlign: TextAlign.right,
                          ),
                          Icon(
                            Icons.info,
                            color: Colors.black,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                ],
              ),
            ),
            const Expanded(
              child: SizedBox(),
            ),
            MainButton(
              title: "تسجيل الخروج",
              onPressed: () {
                deleteUserFromLocal();
                Get.offAll(
                  () => const WelcomeScreen(),
                );
              },
              backgroundColor: Assets.shared.primaryColor,
            ),
            const SizedBox(
              height: 20,
            ),
          ],
        ),
      ),
    );
  }
}
