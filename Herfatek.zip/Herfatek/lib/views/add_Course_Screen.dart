import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svprogresshud/flutter_svprogresshud.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';

import '../custom_widgets/custom_app_bar.dart';
import '../custom_widgets/custom_text.dart';
import '../custom_widgets/custom_text_field.dart';
import '../custom_widgets/main_button.dart';
import '../services/firebase_operations.dart';
import '../utils/assets.dart';

class AddCourseScreen extends StatefulWidget {
  AddCourseScreen({Key? key}) : super(key: key);

  @override
  State<AddCourseScreen> createState() => _AddCourseScreenState();
}

class _AddCourseScreenState extends State<AddCourseScreen> {
  XFile? imageFile;
  String selectedCityTypeID = "";
  String city = "";
  String imageUrl = "";

  String title = "";
  String details = "";
  String courseUrl = "";
  String type = "";

  List<String> types = ["دورة", "ورشة عمل"];

  Future getImage() async {
    // if (Platform.isAndroid) {
    //   await [Permission.camera, Permission.mediaLibrary].request();
    // }
    final ImagePicker _picker = ImagePicker();
    imageFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {});
  }

  Future uploadImage() async {
    SVProgressHUD.show();
    String fileName = DateTime.now().millisecondsSinceEpoch.toString();
    UploadTask uploadTask = uploadFile(File(imageFile!.path), fileName);
    try {
      TaskSnapshot snapshot = await uploadTask;
      imageUrl = await snapshot.ref.getDownloadURL();
      setState(() {
        saveCourseToFire(title, details, imageUrl,
            type == "دورة" ? "course" : "workshop", courseUrl);
        Fluttertoast.showToast(msg: "تمت الاضافة بنجاح");
        SVProgressHUD.dismiss();
      });
    } on FirebaseException catch (e) {
      SVProgressHUD.dismiss();
      Fluttertoast.showToast(msg: e.message ?? e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: '',
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.r),
        child: SizedBox(
          width: double.infinity,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    getImage();
                  },
                  child: Container(
                    // padding: EdgeInsets.symmetric(horizontal: 14.w),
                    height: 100.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        border:
                            Border.all(color: Colors.grey.withOpacity(0.5))),
                    child: (imageFile != null)
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(15),
                            child: Image.file(
                              File(imageFile!.path),
                              fit: BoxFit.fill,
                              // height: 200.h,
                              width: double.infinity,
                            ),
                          )
                        : Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(
                                Icons.image,
                                size: 60,
                                color: Colors.black,
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              CustomText(
                                text: "ارفق صورة الدورة",
                                textColor: Colors.grey,
                                fontSize: 13,
                              ),
                            ],
                          ),
                  ),
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  onChanged: (val) {
                    title = val;
                  },
                  decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 0, color: Colors.grey),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "اسم الدورة"),
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  onChanged: (val) {
                    details = val;
                  },
                  decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 0, color: Colors.grey),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "تفاصيل الدورة"),
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  onChanged: (val) {
                    courseUrl = val;
                  },
                  decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(width: 0, color: Colors.grey),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "رابط الدورة"),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.center,
                  children: [
                    CustomTextField(
                      labelTitle: "اختر النوع",
                      labelHidden: true,
                      initialValue: type,
                      textInputAction: TextInputAction.next,
                      readOnly: true,
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        color: Colors.black,
                      ),
                      labelColor: Colors.black,
                      textAlign: TextAlign.right,
                      onSaved: (String? value) {
                        type = value ?? "";
                      },
                    ),
                    Column(
                      children: [
                        const SizedBox(
                          height: 35,
                        ),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: DropdownButton(
                              icon: const SizedBox(),
                              underline: const SizedBox(),
                              items: types.map((items) {
                                return DropdownMenuItem<String>(
                                  value: items,
                                  child: Text(items),
                                );
                              }).toList(),
                              onChanged: (val) {
                                setState(() {
                                  var index = types.indexOf(val!);
                                  type = types[index];
                                });
                              }),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                MainButton(
                  title: "ارفاق",
                  backgroundColor: Assets.shared.primaryColor,
                  onPressed: () {
                    if (imageFile == null) {
                      Fluttertoast.showToast(msg: "الرجاء اختيار صورة المنتج");
                      return;
                    }
                    if (title == "") {
                      Fluttertoast.showToast(msg: "الرجاء ادخال اسم المنتج");
                      return;
                    }
                    if (details == "") {
                      Fluttertoast.showToast(msg: "الرجاء ادخال تفاصيل المنتج");
                      return;
                    }
                    if (type == "") {
                      Fluttertoast.showToast(msg: "الرجاء اختيار النوع");
                      return;
                    }
                    uploadImage();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
