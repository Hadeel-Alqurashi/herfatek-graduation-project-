import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:herfatek/custom_widgets/custom_text.dart';
import 'package:herfatek/custom_widgets/main_button.dart';
import 'package:herfatek/model/craft_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:herfatek/utils/assets.dart';
import 'package:herfatek/views/course_details_screen.dart';
import 'package:herfatek/views/herfy_details_screen.dart';

import '../custom_widgets/custom_text_field.dart';
import '../model/craft_types_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<CraftTypesModel> cityType = [];
  String selectedCityTypeID = "";
  String city = "";

  String type = "";
  String selectedCraftTypeID = "";
  List<CraftTypesModel> craftsType = [];
  var selectedCraftIndex = 0;

  CraftTypesModel? selectedCraft;
  CraftTypesModel? selectedCity;

  void fetchCities() async {
    List<CraftTypesModel> types = await getCities();
    setState(() {
      cityType.add(CraftTypesModel(uid: '0', title: "الجميع", imgUrl: ""));
      cityType.addAll(types);
      selectedCity = cityType[0];
    });
  }

  void fetchCrafts() async {
    List<CraftTypesModel> types = await getCraftsTypes();
    setState(() {
      craftsType.add(CraftTypesModel(uid: '0', title: "الجميع", imgUrl: ""));

      craftsType.addAll(types);
      selectedCraft = craftsType[0];
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCrafts();
    fetchCities();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "الرئيسية",
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Expanded(
              child: FutureBuilder(
                  future: getCrafts(),
                  builder: (context, AsyncSnapshot<List<CraftModel>> snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data?.length ?? 0,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: EdgeInsets.only(bottom: 20.h),
                            height: 150,

                            // color: Colors.red,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      CustomText(
                                        text: snapshot.data?[index].title ?? "",
                                        alignment: Alignment.bottomRight,
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          text: snapshot.data?[index].details ??
                                              "",
                                          fontSize: 13,
                                          alignment: Alignment.centerRight,
                                          textAlign: TextAlign.right,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 4,
                                      ),
                                      SizedBox(
                                        height: 40,
                                        child: MainButton(
                                          title: "تفاصيل الحرفة",
                                          fontSize: 12,
                                          onPressed: () {
                                            Get.to(() => HerfyDetailsScreen(
                                                craft: snapshot.data![index]));
                                          },
                                          backgroundColor:
                                              Assets.shared.primaryColor,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  height: 150,
                                  width: 180,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Colors.black,
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: Image.network(
                                      snapshot.data?[index].imageUrl ?? "",
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const SizedBox();
                    } else {
                      return Center(
                        child: Container(
                          width: 50,
                          height: 50,
                          child: CircularProgressIndicator(
                            color: Assets.shared.primaryColor,
                          ),
                        ),
                      );
                    }
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
