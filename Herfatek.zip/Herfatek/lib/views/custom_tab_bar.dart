import 'package:flutter/material.dart';
import 'package:herfatek/views/add_Course_Screen.dart';
import 'package:herfatek/views/courses_screen.dart';
import 'package:herfatek/views/home_screen.dart';
import 'package:herfatek/views/places_screen.dart';
import 'package:herfatek/views/profile_screen.dart';

import '../utils/assets.dart';
import 'herfy_screen.dart';

class CustomTabBar extends StatefulWidget {
  const CustomTabBar({super.key});

  @override
  _CustomTabBarState createState() => _CustomTabBarState();
}

class _CustomTabBarState extends State<CustomTabBar>
    with TickerProviderStateMixin {
  final PageStorageBucket bucket = PageStorageBucket();
  late TabController tabController;
  // late bool isSignIn;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 5, vsync: this);
    tabController.addListener(_handleTabSelection);
    checkSignIn();
  }

  void _handleTabSelection() {
    print(tabController.index);

    setState(() {});
  }

  int _currentIndex = 0;
  final List<Widget> _children = [
    PlacesScreen(),
    CoursesScreen(),
    HomeScreen(),
    HerfyScreen(),
    ProfileScreen(),
    // const HajProfileScreen(),
  ];

  Future<void> checkSignIn() async {
    // bool isSignedIn = await checkUserSignIn();
    // this.isSignIn = isSignedIn;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: PageStorage(
        bucket: bucket,
        child: TabBarView(
          controller: tabController,
          physics: const NeverScrollableScrollPhysics(),
          children: _children,
        ),
      ),

      bottomNavigationBar: Material(
        color: Colors.white,
        // elevation: 0,
        child: BottomAppBar(
          color: Colors.white,
          child: TabBar(
            physics: NeverScrollableScrollPhysics(),
            controller: tabController,
            tabs: [
              Tab(
                icon: Icon(
                  Icons.location_history,
                  color: tabController.index == 0
                      ? Assets.shared.primaryColor
                      : Colors.black,
                ),
                text: "المنتجات",
              ),
              Tab(
                icon: Icon(
                  Icons.play_circle_fill,
                  color: tabController.index == 1
                      ? Assets.shared.primaryColor
                      : Colors.black,
                ),
                text: "الدورات",
              ),
              Tab(
                icon: Icon(
                  Icons.home,
                  color: tabController.index == 2
                      ? Assets.shared.primaryColor
                      : Colors.black,
                ),
                text: "الرئيسية",
              ),
              Tab(
                icon: Icon(
                  Icons.supervised_user_circle,
                  color: tabController.index == 3
                      ? Assets.shared.primaryColor
                      : Colors.black,
                ),
                text: "الحرفيين",
              ),
              Tab(
                icon: Icon(
                  Icons.person,
                  color: tabController.index == 4
                      ? Assets.shared.primaryColor
                      : Colors.black,
                ),
                text: "الحساب",
              ),
            ],
            isScrollable: false,
            // labelColor: Colors.black,
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorColor: Colors.transparent,
          ),
        ),
      ),

      // bottomNavigationBar: BottomAppBarItems(
      //   index: 2,
      // ),
    );
  }

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
}
