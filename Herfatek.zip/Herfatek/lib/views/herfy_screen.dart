import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:herfatek/custom_widgets/custom_text.dart';
import 'package:herfatek/custom_widgets/main_button.dart';
import 'package:herfatek/model/craft_model.dart';
import 'package:herfatek/services/firebase_operations.dart';
import 'package:herfatek/utils/assets.dart';
import 'package:herfatek/views/course_details_screen.dart';
import 'package:herfatek/views/herfy_details_screen.dart';
import 'package:herfatek/views/herfy_profile.dart';

import '../custom_widgets/custom_text_field.dart';
import '../model/craft_types_model.dart';

class HerfyScreen extends StatefulWidget {
  const HerfyScreen({Key? key}) : super(key: key);

  @override
  _HerfyScreenState createState() => _HerfyScreenState();
}

class _HerfyScreenState extends State<HerfyScreen> {
  CraftModel? _craft;
  CraftTypesModel? _craftType;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  void fetchCraft(String uid) async {
    var craft = await getCraftByUid(uid);
    _craft = craft;
    print("title");
    print(craft?.title);
    print(uid);

    // setState(() {
    //   _craft = craft;
    //   print(_craft?.title);
    // });
  }

  void fetchCraftType(String uid) async {
    var craft = await getCraftsTypesByUid(uid);
    _craftType = craft;
  }

  void fetchCrafts() async {
    List<CraftTypesModel> types = await getCraftsTypes();
    setState(() {
      // craftsType.add(CraftTypesModel(uid: '0', title: "الجميع"));
      //
      // craftsType.addAll(types);
      // selectedCraft = craftsType[0];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "الحرفيين",
          style: TextStyle(color: Colors.black),
        ),
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Expanded(
              child: FutureBuilder(
                  future: getHerfiesFromFire(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                        itemCount: snapshot.data?.length ?? 0,
                        itemBuilder: (context, index) {
                          // fetchCraft(snapshot.data?[index].craftId ?? "");
                          fetchCraftType(snapshot.data?[index].craftId ?? "");

                          return InkWell(
                            onTap: () {
                              // Get.to(
                              //   () => HerfyDetailsScreen(),
                              // );
                              Get.to(
                                () => HerfyProfileScreen(
                                  user: snapshot.data![index],
                                ),
                              );
                            },
                            child: Container(
                              margin: EdgeInsets.only(bottom: 20.h),
                              height: 180,
                              // color: Colors.red,
                              child: Stack(
                                children: [
                                  Container(
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(15),
                                      child: (_craftType?.imgUrl == null)
                                          ? Image.asset(
                                              Assets.shared.imgCraft,
                                              fit: BoxFit.fill,
                                            )
                                          : Image.network(
                                              _craftType?.imgUrl ?? "",
                                              fit: BoxFit.fill,
                                            ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 10,
                                    right: 0,
                                    child: InkWell(
                                      onTap: () {
                                        Get.to(
                                          () => HerfyProfileScreen(
                                            user: snapshot.data![index],
                                          ),
                                        );
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 10),
                                        width: 170,
                                        height: 80,
                                        color: Assets.shared.primaryColor
                                            .withOpacity(0.7),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            CustomText(
                                              text: _craftType?.title ?? "",
                                              textColor: Colors.black,
                                              fontWeight: FontWeight.bold,
                                              alignment: Alignment.centerRight,
                                              fontSize: 14,
                                            ),
                                            const SizedBox(
                                              height: 8,
                                            ),
                                            Row(
                                              children: [
                                                ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  child: (snapshot.data?[index]
                                                              .userImageUrl ==
                                                          null)
                                                      ? Image.asset(
                                                          Assets
                                                              .shared.imgUser2,
                                                          width: 30,
                                                          height: 30,
                                                        )
                                                      : Image.network(
                                                          snapshot.data?[index]
                                                                  .userImageUrl ??
                                                              "",
                                                          width: 30,
                                                          height: 30,
                                                          fit: BoxFit.fill,
                                                        ),
                                                ),
                                                const SizedBox(
                                                  width: 8,
                                                ),
                                                CustomText(
                                                  text: snapshot
                                                          .data?[index].name ??
                                                      "",
                                                  textColor: Colors.black,
                                                  alignment:
                                                      Alignment.centerRight,
                                                  fontSize: 14,
                                                ),
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    } else if (snapshot.hasError) {
                      return const SizedBox();
                    } else {
                      return Center(
                        child: SizedBox(
                          width: 50,
                          height: 50,
                          child: CircularProgressIndicator(
                            color: Assets.shared.primaryColor,
                          ),
                        ),
                      );
                    }
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
