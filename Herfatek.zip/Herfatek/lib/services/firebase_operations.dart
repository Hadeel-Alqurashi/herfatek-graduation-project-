import 'dart:math';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_svprogresshud/flutter_svprogresshud.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get_storage/get_storage.dart';
import 'package:herfatek/model/courses_model.dart';
import 'package:herfatek/model/craft_model.dart';
import 'package:herfatek/model/craft_types_model.dart';
import 'package:herfatek/model/pages_model.dart';

import '../model/status_response.dart';
import '../model/user_model.dart';
import 'firebase_constants.dart';

FirebaseAuth auth = FirebaseAuth.instance;
FirebaseFirestore db = FirebaseFirestore.instance;
FirebaseStorage firebaseStorage = FirebaseStorage.instance;

Future<StatusResponse> createFireUser(
  String email,
  String name,
  String userName,
  String password,
  String isHerfy,
  String craftId,
  String twitterUrl,
  String instagramUrl,
) async {
  SVProgressHUD.show();

  try {
    UserCredential result = (await auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    ));
    User? user = result.user;
    if (user != null) {
      db.collection(FirebaseConstants.pathUserCollection).doc(user.uid).set({
        FirebaseConstants.pathUserEmail: email,
        FirebaseConstants.pathUserPassword: password,
        FirebaseConstants.pathName: name,
        FirebaseConstants.pathUserName: userName,
        FirebaseConstants.pathUserIsVerified: "0",
        FirebaseConstants.pathIsHerfy: isHerfy,
        FirebaseConstants.pathCraftId: craftId,
        FirebaseConstants.pathTwitterUrl: twitterUrl,
        FirebaseConstants.pathInstagramUrl: instagramUrl,
      }).then((value) {
        print("saved user to Firestore");

        UserModel us = UserModel(
            uid: user.uid,
            email: email,
            name: name,
            password: password,
            userName: userName,
            isVerified: "0");
        GetStorage box = GetStorage();
        box.write(FirebaseConstants.userStoragePath, us.toJson());
      });
      SVProgressHUD.dismiss();
      return StatusResponse(message: "تم التسجيل بنجاح", status: true);
    } else {
      SVProgressHUD.dismiss();
      return StatusResponse(
          message: "حدث خطأ، يرجى المحاولة لاحقاً", status: false);
    }
  } on FirebaseException catch (e, w) {
    print(e.code);
    SVProgressHUD.dismiss();

    if (e.code == "email-already-in-use") {
      return StatusResponse(
          message: "البريد الالكتروني مستخدم من قبل", status: false);
    } else if (e.code == "weak-password") {
      return StatusResponse(
          message: "كلمة المرور يجب أن تكون ٦ أحرف على الأقل", status: false);
    } else {
      return StatusResponse(
          message: "حدث خطأ، يرجى المحاولة لاحقاً", status: false);
    }
  }
}

Future<StatusResponse> signInFireUser(String email, String password) async {
  SVProgressHUD.show();

  try {
    User? user = (await auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    ))
        .user;
    SVProgressHUD.dismiss();

    return StatusResponse(message: "", status: true);
  } on FirebaseException catch (e, w) {
    SVProgressHUD.dismiss();

    print(e.code);
    if (e.code == "user-not-found") {
      return StatusResponse(
          message: "الايميل غير مسجل، يرجى التسجيل في التطبيق", status: false);
    } else if (e.code == "wrong-password") {
      return StatusResponse(message: "كلمة المرور خاطئة", status: false);
    } else {
      return StatusResponse(
          message: "حدث خطأ، يرجى المحاولة لاحقاً", status: false);
    }
  }
}

Future<void> updateUserData(String craftId, String twitterUrl,
    String instagramUrl, String about, String userImageUrl) async {
  var uuid = getLocalUserUuid();
  db.collection(FirebaseConstants.pathUserCollection).doc(uuid!).update({
    FirebaseConstants.pathCraftId: craftId,
    FirebaseConstants.pathTwitterUrl: twitterUrl,
    FirebaseConstants.pathInstagramUrl: instagramUrl,
    FirebaseConstants.pathUserAbout: about,
    FirebaseConstants.pathUserImageURl: userImageUrl,
  }).then((value) async {
    Fluttertoast.showToast(msg: "تم الحفظ بنجاح");
    UserModel? user = await getCurrentUser(uuid);
    if (user != null) {
      saveUserToLocal(user);
    }
  });
}

Future<void> updateUserName(String newName) async {
  var uuid = getLocalUserUuid();
  db.collection(FirebaseConstants.pathUserCollection).doc(uuid!).update({
    FirebaseConstants.pathName: newName,
  }).then((value) async {
    Fluttertoast.showToast(msg: "تم الحفظ بنجاح");
    UserModel? user = await getCurrentUser(uuid);
    if (user != null) {
      saveUserToLocal(user);
    }
  });
}

Future<UserModel?> getCurrentUser(String uid) async {
  SVProgressHUD.show();

  final DocumentSnapshot result =
      await db.collection(FirebaseConstants.pathUserCollection).doc(uid).get();
  print(result.data());
  SVProgressHUD.dismiss();

  if (result.exists) {
    UserModel userObj = UserModel.fromDocument(result);
    print("user exists");
    return userObj;
  } else {
    return null;
  }
}

String? getLocalUserUuid() {
  GetStorage box = GetStorage();
  var user = box.read(FirebaseConstants.userStoragePath);
  if (user != null) {
    return UserModel.fromJson(user).uid;
  } else {
    return null;
  }
}

UserModel? getLocalUser() {
  GetStorage box = GetStorage();
  var user = box.read(FirebaseConstants.userStoragePath);
  if (user != null) {
    return UserModel.fromJson(user);
  } else {
    return null;
  }
}

Future<UserModel?> getUserByUid(String uid) async {
  final DocumentSnapshot result =
      await db.collection(FirebaseConstants.pathUserCollection).doc(uid).get();

  if (result.exists) {
    UserModel user = UserModel.fromDocument(result);
    return user;
  } else {
    return null;
  }
}

Future<CraftModel?> getCraftByUid(String uid) async {
  final DocumentSnapshot result = await db
      .collection(FirebaseConstants.pathCraftsCollection)
      .doc(uid)
      .get();

  if (result.exists) {
    CraftModel craft = CraftModel.fromDocument(result);
    return craft;
  } else {
    return null;
  }
}

Future<List<UserModel>> getHerfiesFromFire() async {
  final QuerySnapshot result =
      await db.collection(FirebaseConstants.pathUserCollection).get();
  final List<DocumentSnapshot> documents = result.docs;

  List<UserModel> myListString = []; // My list I want to create.

  documents.forEach((snapshot) {
    UserModel user = UserModel.fromDocument(snapshot);
    if (user.isHerfy == "1") {
      myListString.add(user);
    }
  });

  return myListString;
}

Future<List<CraftTypesModel>> getCraftsTypes() async {
  final QuerySnapshot result = await db.collection('craftsType').get();
  final List<DocumentSnapshot> documents = result.docs;
  print(documents);

  List<CraftTypesModel> myListString = []; // My list I want to create.

  documents.forEach((snapshot) {
    CraftTypesModel craftModel = CraftTypesModel.fromDocument(snapshot);
    //
    myListString.add(craftModel);
    // print(snapshot.get("title"));
  });

  return myListString;
}

Future<CraftTypesModel> getCraftsTypesByUid(String uid) async {
  final DocumentSnapshot result =
      await db.collection('craftsType').doc(uid).get();
  CraftTypesModel craftModel = CraftTypesModel.fromDocument(result);

  return craftModel;
}

Future<List<CraftModel>> getCrafts() async {
  final QuerySnapshot result = await db.collection('crafts').get();
  final List<DocumentSnapshot> documents = result.docs;
  print(documents);

  List<CraftModel> myListString = [];

  documents.forEach((snapshot) {
    CraftModel craftModel = CraftModel.fromDocument(snapshot);
    //
    myListString.add(craftModel);
    // print(snapshot.get("title"));
  });

  return myListString;
}

Future<List<CraftModel>> getCraftsByUserId(String uid) async {
  final QuerySnapshot result = await db
      .collection('crafts')
      .where(FirebaseConstants.pathCraftUserUID, isEqualTo: uid)
      .get();
  final List<DocumentSnapshot> documents = result.docs;
  print(documents);

  List<CraftModel> myListString = [];

  documents.forEach((snapshot) {
    CraftModel craftModel = CraftModel.fromDocument(snapshot);
    myListString.add(craftModel);
  });

  return myListString;
}

Future<PagesModel?> getPages(String type) async {
  final QuerySnapshot result = await db
      .collection(FirebaseConstants.pathPagesCollection)
      .where(FirebaseConstants.pathType, isEqualTo: type)
      .get();
  final List<DocumentSnapshot> documents = result.docs;

  List<PagesModel> myListString = [];

  documents.forEach((snapshot) {
    PagesModel page = PagesModel.fromDocument(snapshot);
    myListString.add(page);
  });

  return myListString.isNotEmpty ? myListString[0] : null;
}

Future<List<CraftModel>> getCraftsByCraftTypeId(String uid) async {
  final QuerySnapshot result = await db
      .collection('crafts')
      .where(FirebaseConstants.pathCraftId, isEqualTo: uid)
      .get();
  final List<DocumentSnapshot> documents = result.docs;
  print(documents);

  List<CraftModel> myListString = [];

  documents.forEach((snapshot) {
    CraftModel craftModel = CraftModel.fromDocument(snapshot);
    myListString.add(craftModel);
  });

  return myListString;
}

Future<List<CoursesModel>> getCourses() async {
  final QuerySnapshot result =
      await db.collection(FirebaseConstants.pathCoursesCollection).get();
  final List<DocumentSnapshot> documents = result.docs;

  List<CoursesModel> myListString = [];

  documents.forEach((snapshot) {
    CoursesModel craftModel = CoursesModel.fromDocument(snapshot);
    print(craftModel.toJson());

    myListString.add(craftModel);
  });

  return myListString;
}

void saveUserToLocal(UserModel user) {
  GetStorage box = GetStorage();
  box.write(FirebaseConstants.userStoragePath, user.toJson());
}

void deleteUserFromLocal() {
  GetStorage box = GetStorage();
  box.remove(FirebaseConstants.userStoragePath);
}

Future<List<CraftTypesModel>> getCities() async {
  final QuerySnapshot result = await db.collection('cities').get();
  final List<DocumentSnapshot> documents = result.docs;
  print(documents);

  List<CraftTypesModel> myListString = []; // My list I want to create.

  documents.forEach((snapshot) {
    CraftTypesModel craftModel = CraftTypesModel.fromDocument(snapshot);
    //
    myListString.add(craftModel);
    // print(snapshot.get("title"));
  });

  return myListString;
}

UploadTask uploadFile(File image, String fileName) {
  Reference reference = firebaseStorage.ref().child(fileName);
  UploadTask uploadTask = reference.putFile(image);
  return uploadTask;
}

Future<void> saveCraftToFire(String title, String details, String imageUrl,
    String cityId, String craftUrl) async {
  var user = getLocalUser();

  db.collection(FirebaseConstants.pathCraftsCollection).doc().set({
    FirebaseConstants.pathCraftTitle: title,
    FirebaseConstants.pathCraftDetails: details,
    FirebaseConstants.pathCraftImageUrl: imageUrl,
    FirebaseConstants.pathCityId: cityId,
    FirebaseConstants.pathCraftUrl: craftUrl,
    FirebaseConstants.pathCraftId: user?.craftId ?? "",
    FirebaseConstants.pathCraftUserUID: user?.uid ?? "",
  }).then((value) {
    print("saved craft to Firestore");
  });
}

Future<void> saveCourseToFire(String title, String details, String imageUrl,
    String type, String courseUrl) async {
  var user = getLocalUser();

  db.collection(FirebaseConstants.pathCoursesCollection).doc().set({
    FirebaseConstants.pathCraftTitle: title,
    FirebaseConstants.pathCraftDetails: details,
    FirebaseConstants.pathCraftImageUrl: imageUrl,
    FirebaseConstants.pathType: type,
    FirebaseConstants.pathCraftUrl: courseUrl,
    FirebaseConstants.pathCraftUserUID: user?.uid ?? "",
  }).then((value) {
    print("saved craft to Firestore");
  });
}
