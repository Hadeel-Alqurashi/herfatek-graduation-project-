class FirebaseConstants {
  // User constants
  static const pathUserCollection = "users";
  static const pathUserEmail = "u_email";
  static const pathUserUuid = "u_uuid";
  static const pathUserPassword = "u_password";
  static const pathUserId = "u_id";
  static const pathName = "u_name";
  static const pathUserName = "u_user_name";
  static const pathUserOtp = "u_otp";
  static const pathUserIsVerified = "u_is_verified";
  static const pathIsHerfy = "u_is_herfy";
  static const pathCraftId = "u_craft_id";
  static const pathTwitterUrl = "u_twitter_url";
  static const pathInstagramUrl = "u_instagram_url";
  static const pathUserImageURl = "u_user_img_url";
  static const pathUserAbout = "u_about";

  static const pathCraftsCollection = "crafts";
  static const pathCraftUid = "uid";
  static const pathCraftTitle = "title";
  static const pathCraftDetails = "details";
  static const pathCraftImageUrl = "image_url";
  static const pathCityId = "city_id";
  static const pathCraftUserUID = "user_uid";
  static const pathCraftUrl = "craft_url";
  static const pathType = "type";

  static const pathCoursesCollection = "courses";

  static const pathCraftTypeImg = "imgUrl";

  static const pathPagesCollection = "pages";
  static const pathTxt = "txt";

  // other constants
  static const userStoragePath = "userData";
  static const otpStoragePath = "otp_data";
}
