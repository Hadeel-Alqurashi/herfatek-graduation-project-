import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/assets.dart';
import 'custom_text.dart';

class MainButton extends StatelessWidget {
  final String title;
  final double? fontSize;
  final FontWeight? fontWeight;
  final VoidCallback onPressed;
  final Color? backgroundColor;

  const MainButton({
    Key? key,
    required this.title,
    required this.onPressed,
    this.fontWeight,
    this.fontSize,
    this.backgroundColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: backgroundColor ?? Colors.white,
        padding: EdgeInsets.all(8.r),
      ).copyWith(
        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(20.r)),
          ),
        ),
      ),
      child: CustomText(
        text: title,
        textColor: Colors.white,
        fontSize: fontSize ?? 16,
        fontWeight: fontWeight ?? FontWeight.bold,
      ),
    );
  }
}
