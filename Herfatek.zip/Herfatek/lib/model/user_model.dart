import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_constants.dart';

class UserModel {
  String uid;
  String email;
  String password;
  String? isVerified;
  String? name;
  String? userName;
  String? isHerfy;
  String? craftId;
  String? twitterUrl;
  String? instagramUrl;
  String? userImageUrl;
  String? about;

  UserModel({
    required this.uid,
    required this.email,
    required this.password,
    required this.name,
    required this.userName,
    this.isVerified,
    this.isHerfy,
    this.craftId,
    this.twitterUrl,
    this.instagramUrl,
    this.userImageUrl,
    this.about,
  });

  Map<String, dynamic> toJson() => {
        FirebaseConstants.pathUserUuid: uid,
        FirebaseConstants.pathUserEmail: email,
        FirebaseConstants.pathName: name,
        FirebaseConstants.pathUserName: userName,
        FirebaseConstants.pathUserPassword: password,
        FirebaseConstants.pathIsHerfy: isHerfy,
        FirebaseConstants.pathCraftId: craftId,
        FirebaseConstants.pathTwitterUrl: twitterUrl,
        FirebaseConstants.pathInstagramUrl: instagramUrl,
        FirebaseConstants.pathUserImageURl: userImageUrl,
        FirebaseConstants.pathUserAbout: about,
        FirebaseConstants.pathUserIsVerified:
            isVerified == null ? null : isVerified,
      };

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        uid: json[FirebaseConstants.pathUserUuid],
        email: json[FirebaseConstants.pathUserEmail],
        name: json[FirebaseConstants.pathName],
        userName: json[FirebaseConstants.pathUserName],
        password: json[FirebaseConstants.pathUserPassword],
        isHerfy: json[FirebaseConstants.pathIsHerfy],
        craftId: json[FirebaseConstants.pathCraftId],
        twitterUrl: json[FirebaseConstants.pathTwitterUrl],
        instagramUrl: json[FirebaseConstants.pathInstagramUrl],
        userImageUrl: json[FirebaseConstants.pathUserImageURl],
        about: json[FirebaseConstants.pathUserAbout],
        isVerified: json[FirebaseConstants.pathUserIsVerified] == null
            ? null
            : json[FirebaseConstants.pathUserIsVerified],
      );

  factory UserModel.fromDocument(DocumentSnapshot doc) {
    String uid = "";
    String email = "";
    String name = "";
    String userName = "";
    String password = "";
    String otp = "";
    String isVerified = "";
    String isHerfy = "";
    String craftId = "";
    String twitterUrl = "";
    String instagramUrl = "";
    String userImageUrl = "";
    String about = "";

    try {
      uid = doc.id;
    } catch (e) {}

    try {
      email = doc.get(FirebaseConstants.pathUserEmail);
    } catch (e) {}

    try {
      name = doc.get(FirebaseConstants.pathName);
    } catch (e) {}

    try {
      userName = doc.get(FirebaseConstants.pathUserName);
    } catch (e) {}

    try {
      userImageUrl = doc.get(FirebaseConstants.pathUserImageURl);
    } catch (e) {}

    try {
      about = doc.get(FirebaseConstants.pathUserAbout);
    } catch (e) {}

    try {
      password = doc.get(FirebaseConstants.pathUserPassword);
    } catch (e) {
      // print(e.toString());
    }

    try {
      otp = doc.get(FirebaseConstants.pathUserOtp);
    } catch (e) {}

    try {
      isVerified = doc.get(FirebaseConstants.pathUserIsVerified);
    } catch (e) {}

    try {
      isHerfy = doc.get(FirebaseConstants.pathIsHerfy);
    } catch (e) {}
    try {
      craftId = doc.get(FirebaseConstants.pathCraftId);
    } catch (e) {}
    try {
      twitterUrl = doc.get(FirebaseConstants.pathTwitterUrl);
    } catch (e) {}

    try {
      instagramUrl = doc.get(FirebaseConstants.pathInstagramUrl);
    } catch (e) {}

    return UserModel(
      uid: uid,
      email: email,
      name: name,
      password: password,
      userName: userName,
      isVerified: isVerified,
      isHerfy: isHerfy,
      craftId: craftId,
      twitterUrl: twitterUrl,
      instagramUrl: instagramUrl,
      userImageUrl: userImageUrl,
      about: about,
    );
  }
}
