class StatusResponse {
  String message;
  bool status;

  StatusResponse({
    required this.message,
    required this.status,
  });
}
