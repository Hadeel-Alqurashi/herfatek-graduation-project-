import 'package:flutter/material.dart';

const String _imagesPath = "assets/images/";

const String _iconsPath = "${_imagesPath}icons/";

class Assets {
  static final shared = Assets();

  // TODO: - Colors

  final Color primaryColor = const Color(0xFFEEB840);

  final Color secondaryColor = const Color(0xffD3E7EE);

  final Color F5F5F5 = const Color(0xFFF5F5F5);

  final Color emptyColor = const Color(0xffa09d9d);

  final Color scaffoldBackgroundColor = const Color(0xffffffff);

  // TODO: - Fonts

  final String primaryFont = 'NeoSansArabic';

  // TODO: - Icons

  final String icLogo = "${_iconsPath}0h.jpeg";
  final String icTwitter = "${_iconsPath}twitter.png";
  final String icInstagram = "${_iconsPath}instagram.png";

  // TODO: - Images

  final String bgSplash = "${_imagesPath}bg_splash.png";
  final String imgCraft = "${_imagesPath}craft.jpeg";
  final String imgCraft2 = "${_imagesPath}craft2.jpeg";
  final String imgUser = "${_imagesPath}user.png";
  final String imgUser2 = "${_imagesPath}user2.png";
}
