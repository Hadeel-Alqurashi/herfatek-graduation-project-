package com.example.herfatek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
